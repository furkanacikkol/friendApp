#!/usr/bin/env python
# -*- coding: UTF-8 -*-

from ilk_proje.node.motor import PWM_OUTPUT
from ilk_proje.node.two_motor import PWM_OUTPUT2
import rospy
from ilk_proje.msg import zaman
from rospy.topics import Publisher


pub = rospy.Publisher('rov_topic',zaman,queue_size=10)

rospy.init_node('publisher',anonymous= True)

rate = rospy.Rate(10)

i = 0

while(not rospy.is_shutdown()):

    rov_bilgi = zaman()

    rov_bilgi.hiz = PWM_OUTPUT
    rov_bilgi.hiz = PWM_OUTPUT2
    

    rospy.loginfo(rov_bilgi)

    pub.publish(rov_bilgi)

    rate.sleep()

    i = i+1
 



