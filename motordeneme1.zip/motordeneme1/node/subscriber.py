#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import rospy
from motordeneme1.msg import rov

from navio2_ros.msg import rov

from navio2_ros.navio.pwm import PWM
from rospy import msg


def callback(msg):

   rospy.loginfo('alinan veriler: (%d)',
   data.hiz)


   rospy.init_node('rov_topic',anonymous=True)

rospy.Subscriber('rov_topic',rov,callback=msg)
rospy.init_node('subscriber')

sub = rospy.Subscriber('rov_topic',rov, callback)
rospy.spin()


