import sys
import time
import rospy
from motordeneme1.msg import rov


import navio.pwm
import navio.util
import numpy as np
navio.util.check_apm()

pub = rospy.Publisher('rov_topic',rov, queue_size=10)

rospy.init_node('publisher',anonymous= True)

rate = rospy.Rate(10)


rospy.init_node('subscriber',anonymous=True) 


PWM_OUTPUT = 0
PWM_OUTPUT2 = 1
SERVO_MIN = 1.250 #ms
SERVO_MAX = 1.750 #ms
servo_set = 1
servo_set2 = 1.750
with navio.pwm.PWM(PWM_OUTPUT) as pwm, navio.pwm.PWM(PWM_OUTPUT2) as pwm2:
 pwm.set_period(50)
 pwm.set_duty_cycle(1)
 pwm2.set_period(50)
 pwm2.set_duty_cycle(1)
 time.sleep(5)
 while True:
  pwm.set_duty_cycle(1.250)
  pwm2.set_duty_cycle(1.250)
 